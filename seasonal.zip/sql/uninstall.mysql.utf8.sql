DROP TABLE IF EXISTS `#__seasonal`;
